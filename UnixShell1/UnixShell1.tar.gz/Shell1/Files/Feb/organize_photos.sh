#!/bin/bash
mv Files/Feb/pics/*.jpg Photos/
mv Files/Jul/Vacation/*.jpg Photos/
mv Files/Dec/Holidays/*.jpg Photos/
mv Files/Apr/user/Sally/Alaska/*.jpg Photos/
